<?php

namespace App\Livewire;

use Livewire\Component;

class EditStock extends Component
{
    public function render()
    {
        return view('livewire.edit-stock');
    }
}
