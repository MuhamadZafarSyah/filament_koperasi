<?php $__env->startSection('script_alpine'); ?>
    <script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js"></script>
    <script defer="" src="https://cdn.jsdelivr.net/npm/@alpinejs/intersect@3.x.x/dist/cdn.min.js"></script>
    <script defer="" src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="p-4">
        <?php if($checkout->isEmpty()): ?>
            <div class="w-full h-[80vh] flex items-center justify-center overflow-hidden p-4">
                <h1 class="text-xl font-bold text-gray-700">Tidak Ada Riwayat Transaksi</h1>
            </div>
        <?php else: ?>
            <h1 class="font-bold">Riwayat Transaksi</h1>
            <div class="mt-6 flex flex-col gap-4 pb-28">
                <?php $__currentLoopData = $checkout; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="border relative  rounded-lg  shadow-xl drop-shadow-2xl p-4">
                        <h1 class="font-bold">Total transaksi</h1>
                        <h2 class="text-lg">Rp <?php echo e(number_format($item->total_harga, 0, ',', '.')); ?></h2>
                        <h1 class="font-bold">Kode unik transaksi</h1>
                        <h2 class="text-lg"><?php echo e($item->kode_bukti); ?></h2>
                        <div class="flex items-end justify-between" x-data="{ open: false }">
                            <?php if($item->status == 'Pending'): ?>
                                <span
                                    class="inline-flex items-center bg-orange-100 text-orange-800 text-xs font-medium px-2.5 py-0.5 rounded-full dark:bg-orange-900 dark:text-orange-300">
                                    <span class="w-2 h-2 me-1 bg-orange-500 rounded-full"></span>
                                    <?php echo e($item->status); ?>

                                </span>
                            <?php else: ?>
                                <span
                                    class="inline-flex items-center bg-green-100 text-green-800 text-xs font-medium px-2.5 py-0.5 rounded-full dark:bg-green-900 dark:text-green-300">
                                    <span class="w-2 h-2 me-1 bg-green-500 rounded-full"></span>
                                    <?php echo e($item->status); ?>

                                </span>
                            <?php endif; ?>
                            <?php if($item->status == 'Success'): ?>
                                <h1 class="font-bold">Silahkan Temui Petugas!</h1>
                            <?php endif; ?>

                        </div>
                        <div class="absolute top-2 right-2">
                            <span><?php echo e($item->created_at); ?></span>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>
    </section>
    <?php echo $__env->make('components.partials.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('components.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\zafar\Downloads\KOPRASI65\koprasi for production\koprasi\resources\views/transaction.blade.php ENDPATH**/ ?>