<div class="navigation">
    <ul>
        <li class="list <?php echo e(Request::is('/') ? 'active' : ''); ?>">
            <a href="#">
                <a href="#" class="delayed-link" data-href="/">
                    <span class="icon"><ion-icon name="home-outline"></ion-icon></span>
                    <span class="text">Home</span>
                </a>
            </a>
        </li>


        <li class="list <?php echo e(Request::is('transaction') ? 'active' : ''); ?>">
            <a href="#">
                <a href="#" class="delayed-link" data-href="/transaction">
                    <span class="icon"><ion-icon name="receipt-outline"></ion-icon></span>
                    <span class="text">Transaction</span>
                </a>
            </a>
        </li>

        <li class="list <?php echo e(Request::is('profile') ? 'active' : ''); ?>">
            <a href="#">
                <a href="#" class="delayed-link" data-href="/profile">
                    <span class="icon"><ion-icon name="person-outline"></ion-icon></span>
                    <span class="text">Profile</span>
                </a>
            </a>
        </li>

        <div class="indicator"></div>
    </ul>
</div>



<?php /**PATH C:\Users\zafar\Downloads\KOPRASI65\koprasi for production\koprasi\resources\views/components/partials/navbar.blade.php ENDPATH**/ ?>