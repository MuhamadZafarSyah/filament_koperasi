<div class=" -mt-2 ">
    <a href="/profile">
        <img class="w-16 border-4 border-blue-500 rounded-full" src="<?php echo e(Auth::user()->picture); ?>"
            alt="User - Profile Picture">
    </a>
</div>
<?php /**PATH C:\Users\zafar\Downloads\KOPRASI65\koprasi for production\koprasi\resources\views/components/partials/avatar.blade.php ENDPATH**/ ?>