<section class="mt-4 mb-20 no-scrollbar">
    <h1 class="font-munish font-bold text-lg">Cek yang baru di koperasi</h1>
    <div class="w-full">
        <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $new): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <article class="rounded-xl shadow-md bg-white relative pb-4 mt-8">
                <div class="rounded-xl">
                    <img class="rounded-xl max-h-48 object-cover overflow-hidden w-full"
                        src="/storage/<?php echo e($new->image); ?>" alt="News - <?php echo e($new->title); ?>">
                </div>
                <figcaption class="p-2 font-mulish ">
                    <h1 class="text-base font-bold"><?php echo e($new->title); ?></h1>
                    <p class="text-xs"><?php echo e($new->content); ?></p>
                </figcaption>
            </article>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</section>
<?php /**PATH C:\Users\zafar\Downloads\KOPRASI65\koprasi for production\koprasi\resources\views/components/partials/news.blade.php ENDPATH**/ ?>