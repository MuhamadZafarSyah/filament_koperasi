<div class=" -mt-2 ">
    <a href="/profile">
        <img class="w-16 border-4 border-blue-500 rounded-full" src="{{ Auth::user()->picture }}"
            alt="User - Profile Picture">
    </a>
</div>
